# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

import torch
import triton
import triton.language as tl

from fla.ops.utils import prepare_chunk_indices
from fla.ops.utils.op import exp2


@triton.jit()
def chunk_update_once(
    b_p,
    b_k,
    b_v,
    b_m,
    b_g_exp_q,
    b_h,
    b_lamb,
):
    b_o = tl.dot((tl.dot(b_p.to(b_k.dtype), tl.trans(b_k)) * b_m).to(b_v.dtype), b_v)
    b_o += tl.dot((b_p * b_g_exp_q).to(b_h.dtype), b_h)
    if b_lamb is not None:
        b_o += b_lamb[None, :] * b_p
    return b_o


@triton.heuristics({
    'IS_VARLEN': lambda args: args['cu_seqlens'] is not None,
})
@triton.jit(do_not_specialize=['T'])
def chunk_fwd_mesa_cg_dim64_kernel(
    dq,
    dq_final,
    k,
    h,
    g,
    beta,
    lamb,
    cu_seqlens,
    chunk_indices,
    T,
    max_CG_iteration: tl.constexpr,
    H: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0).to(tl.int64), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H

    if IS_VARLEN:
        i_tg = i_t
        i_n, i_t = tl.load(chunk_indices + i_t * 2).to(tl.int32), tl.load(chunk_indices + i_t * 2 + 1).to(tl.int64)
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(cu_seqlens + i_n + 1).to(tl.int32)
        T = eos - bos
        NT = tl.cdiv(T, BT)
    else:
        NT = tl.cdiv(T, BT)
        i_tg = i_b * NT + i_t
        bos, eos = i_b * T, i_b * T + T

    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T

    # offset calculation
    dq += (bos * H + i_h) * K
    dq_final += (bos * H + i_h) * K
    k += (bos * H + i_h) * K
    h += (i_tg * H + i_h).to(tl.int64) * K * K

    g += bos * H + i_h
    beta += bos * H + i_h
    lamb += i_h * K

    o_k = tl.arange(0, BK)
    m_k = o_k < K
    m_tk = m_t[:, None] & m_k[None, :]
    m_kk = m_k[:, None] & m_k[None, :]
    p_q = dq + o_t[:, None] * (H*K) + o_k[None, :]
    p_k = k + o_t[:, None] * (H*K) + o_k[None, :]
    p_h = h + o_k[:, None] * K + o_k[None, :]

    b_h = tl.load(p_h, mask=m_kk, other=0.0)
    b_k = tl.load(p_k, mask=m_tk, other=0.0)
    b_q = tl.load(p_q, mask=m_tk, other=0.0).to(tl.float32)

    p_g = g + o_t * H
    b_g = tl.load(p_g, mask=m_t, other=0.0).to(tl.float32)
    p_beta = beta + o_t * H
    b_beta = tl.load(p_beta, mask=m_t, other=0.0).to(tl.float32)
    p_lamb = lamb + o_k
    b_lamb = tl.load(p_lamb, mask=m_k, other=0.0).to(tl.float32)

    b_m = exp2(b_g[:, None] - b_g[None, :]) * b_beta[None, :]
    b_m = tl.where((o_t[:, None] >= o_t[None, :]) & (m_t[:, None] & m_t[None, :]), b_m, 0)
    b_g_exp_q = exp2(b_g)[:, None]

    b_x = tl.zeros([BT, BK], dtype=tl.float32)
    b_p = tl.zeros([BT, BK], dtype=tl.float32)
    b_r = tl.zeros([BT, BK], dtype=tl.float32)

    b_x += b_q * 0.
    b_r += b_q
    b_p += b_q
    b_delta_old = tl.sum(b_r*b_r, axis=1)
    for _ in range(max_CG_iteration):
        b_o = chunk_update_once(b_p, b_k, b_k, b_m, b_g_exp_q, b_h, b_lamb)
        alpha = b_delta_old / (tl.sum(b_p*b_o, axis=1) + 1e-5)
        b_x += alpha[:, None] * b_p
        b_r = b_r - alpha[:, None] * b_o
        b_delta_new = tl.sum(b_r*b_r, axis=1)
        b_p = b_r + (b_delta_new / (b_delta_old + 1e-5))[:, None] * b_p
        b_delta_old = b_delta_new

    p_q_final = dq_final + o_t[:, None] * (H*K) + o_k[None, :]
    tl.store(p_q_final, b_x.to(p_q_final.dtype.element_ty), mask=m_tk)


def chunk_mesa_cg_bwd(
    dq: torch.Tensor,
    k: torch.Tensor,
    h: torch.Tensor,
    g_local_cumsum: torch.Tensor,
    beta: torch.Tensor,
    lamb: torch.Tensor,  # lambda
    cu_seqlens: torch.Tensor | None = None,
    chunk_size: int = 64,
    max_CG_iteration: int = 30,
    output_dtype: torch.dtype | None = None,
    chunk_indices: torch.LongTensor | None = None,
) -> torch.Tensor:
    B, T, H, K = dq.shape
    assert K <= 128, "head dimension must be less than 128"
    assert chunk_size <= 64 or K <= 64, "either chunk size or head dimension must be no greater than 64"
    dq_final = torch.empty_like(dq, dtype=dq.dtype if output_dtype is None else output_dtype)

    if chunk_indices is None and cu_seqlens is not None:
        chunk_indices = prepare_chunk_indices(cu_seqlens, chunk_size)
    NT = triton.cdiv(T, chunk_size) if cu_seqlens is None else len(chunk_indices)
    BK = max(triton.next_power_of_2(K), 16)
    grid = (NT, H*B)

    chunk_fwd_mesa_cg_dim64_kernel[grid](
        dq=dq,
        dq_final=dq_final,
        k=k,
        h=h,
        g=g_local_cumsum,
        beta=beta,
        lamb=lamb,
        cu_seqlens=cu_seqlens,
        chunk_indices=chunk_indices,
        max_CG_iteration=max_CG_iteration,
        T=T,
        H=H,
        K=K,
        BT=chunk_size,
        BK=BK,
        num_warps=4,
        num_stages=1,
    )
    return dq_final
